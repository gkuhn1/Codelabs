package com.eduardoptorezan.exand_bibliotecamusical;

public enum enumTipoNotificacao {
	Toast, Dialog, ActionBar
}
