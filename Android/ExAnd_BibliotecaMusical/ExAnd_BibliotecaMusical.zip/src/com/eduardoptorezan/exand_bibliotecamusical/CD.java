package com.eduardoptorezan.exand_bibliotecamusical;

import android.widget.TextView;

public class CD {
	public String NomeDoAlbum;
	public String Ano;
	public String Compositor;
	public String Gravadora;
	public String Observacoes;

}
